import { Request, Response } from 'express';

export const handleAIChat = async (req: Request, res: Response) => {
  try {
    const { message, language } = req.body;
    const lowerMsg = message.toLowerCase();

    let responseText = "Our luxury collections feature pure organza, raw silk, and embroidered chiffon. For bespoke sizing, visit our Custom Stitching service.";
    let whatsappEscalate = false;

    if (lowerMsg.includes('bridal') || lowerMsg.includes('shadi') || lowerMsg.includes('lehenga')) {
      responseText = "Our Bridal Wear line features hand-crafted zardozi, dabka, and kamdani work. Prices range from PKR 150,000 to PKR 500,000+. Would you like a consultation?";
    } else if (lowerMsg.includes('size') || lowerMsg.includes('maap') || lowerMsg.includes('measurement')) {
      responseText = "We provide standard Pakistani sizes (XS, S, M, L, XL) as well as Custom Stitching. Please share your exact Chest, Waist, and Hip measurements.";
    } else if (lowerMsg.includes('payment') || lowerMsg.includes('jazzcash') || lowerMsg.includes('cod')) {
      responseText = "We accept Cash on Delivery (COD), JazzCash, Easypaisa, Direct Bank Transfer, and international credit/debit cards via Stripe.";
    } else if (lowerMsg.includes('return') || lowerMsg.includes('exchange')) {
      responseText = "We offer a 7-day exchange and return policy for unworn items with original tags intact. Custom-stitched outfits are non-returnable.";
    } else if (lowerMsg.includes('complex') || lowerMsg.includes('custom') || lowerMsg.includes('issue')) {
      whatsappEscalate = true;
      responseText = "Connecting you directly with our senior fashion consultant on WhatsApp for personalized assistance.";
    }

    res.status(200).json({
      status: 'success',
      reply: responseText,
      whatsappEscalate,
      whatsappNumber: '+923000000000'
    });
  } catch (error: any) {
    res.status(500).json({ status: 'error', message: error.message });
  }
};
