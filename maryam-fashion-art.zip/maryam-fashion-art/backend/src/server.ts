import express, { Application, Request, Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';

dotenv.config();

const app: Application = express();
const PORT = process.env.PORT || 5000;

app.use(helmet());
app.use(cors({ origin: ['https://maryanfashionart.pk', 'http://localhost:3000'], credentials: true }));
app.use(express.json());
app.use(morgan('dev'));

// Health Check
app.get('/api/health', (req: Request, res: Response) => {
  res.status(200).json({ status: 'success', domain: 'maryanfashionart.pk', message: 'API operational' });
});

// Import Routes
import productRoutes from './routes/product.routes';
import orderRoutes from './routes/order.routes';
import authRoutes from './routes/auth.routes';
import aiRoutes from './routes/ai.routes';

app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/ai', aiRoutes);

app.listen(PORT, () => {
  console.log(`[Maryam Fashion Arts] Server running on port ${PORT}`);
});
