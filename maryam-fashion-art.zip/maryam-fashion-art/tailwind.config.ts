import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './frontend/src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './frontend/src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './frontend/src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        luxury: {
          black: '#0A0A0A',
          white: '#FFFFFF',
          gold: '#D4AF37',
          'gold-light': '#F3E5AB',
          beige: '#F5F2EB',
          charcoal: '#1A1A1A',
        },
      },
      fontFamily: {
        serif: ['Playfair Display', 'serif'],
        sans: ['Inter', 'sans-serif'],
      },
    },
  },
  plugins: [],
};

export default config;
